ABOUT:

AoratosWin is a tool that removes traces of executed applications on Windows OS 
which can easily be listed with tools such as ExecutedProgramList by Nirsoft.


Project:

https://github.com/KaizenLouie/AoratosWin
